1. Add the following items to your qb-core/shared/items.lua

['pure_cocaine_brick'] = {['name'] = 'pure_cocaine_brick', ['label'] = 'Pure Coke Brick', ['weight'] = 1000, ['type'] = 'item', ['image'] = 'pure_cocaine_brick.png', ['unique'] = false, ['useable'] = true, ['shouldClose'] = true, ['combinable'] = nil, ['description'] = 'Split it up into grams!'},
['pure_cocaine'] = {['name'] = 'pure_cocaine', ['label'] = 'Pure Coke', ['weight'] = 100, ['type'] = 'item', ['image'] = 'pure_cocaine.png', ['unique'] = false, ['useable'] = true, ['shouldClose'] = true, ['combinable'] = nil, ['description'] = 'Purify this stuff up!'},
['processed_cocaine'] = {['name'] = 'processed_cocaine', ['label'] = 'Refined Coke', ['weight'] = 100, ['type'] = 'item', ['image'] = 'processed_cocaine.png', ['unique'] = false, ['useable'] = true, ['shouldClose'] = true, ['combinable'] = nil, ['description'] = 'Get it in baggys and sell it!'},
['cocaine_baggy'] = {['name'] = 'cocaine_baggy', ['label'] = 'Coke Baggy', ['weight'] = 1000, ['type'] = 'item', ['image'] = 'cocaine_baggy.png', ['unique'] = false, ['useable'] = true, ['shouldClose'] = true, ['combinable'] = nil, ['description'] = 'Ready for the streets.'},

2. Copy the images from /images/ to qb-inventory/html/images